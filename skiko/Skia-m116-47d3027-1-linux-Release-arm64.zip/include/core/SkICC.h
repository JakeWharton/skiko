/*
 * Copyright 2023 Google LLC
 *
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */

// TODO(kjlubick) remove this shim after clients have been moved to the new location
#include "include/encode/SkICC.h" // IWYU pragma: export
